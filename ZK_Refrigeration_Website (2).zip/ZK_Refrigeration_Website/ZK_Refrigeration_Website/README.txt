
ZK_Refrigeration_Website
========================

Files:
- index.html
- styles.css
- scripts.js
- logo.png
- assets/ (contains placeholder images and a placeholder video file)
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="google-site-verification" content="ABCD1234EfGhIjKlMnOpQrStUvWxYz" />
  <title>ZK Refrigeration</title>
</head>

How to deploy on Netlify (manual upload):
1. Go to https://www.netlify.com and sign up / log in.
2. Click "Add new site" -> "Import an existing project" -> "Deploy manually".
3. Drag & drop the ZK_Refrigeration_Website.zip file into the upload area.
4. Netlify will unpack and deploy the site. You can set the site name to 'zkrefrigeration' in site settings if available.

Notes:
- Replace assets/video-placeholder.mp4 with your real MP4 video file (same filename) to enable the video.
- Replace assets/img1.jpg ... img9.jpg with your real gallery images.
- Contact form currently uses mailto: to send an email to zishanali2233445@gmail.com as a fallback.
